/*
Description:
    CIS 415 Project 3 InstaQuack!
    main.c

Author: Joseph Goh
Last updated: 2019/12/08

Notes:
    N/A

TO DO:
    N/A
*/

#include "quacker.h"
#include "topicstore.h"

int main(int argc, char *argv[]) {
    quacker();

    return 0;
}